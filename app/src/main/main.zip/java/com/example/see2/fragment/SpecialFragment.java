package com.example.see2.fragment;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.see2.R;
import com.example.see2.appservice.AppService;
import com.example.see2.bean.ChangBean;
import com.google.gson.Gson;

import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * A simple {@link Fragment} subclass.
 */
public class SpecialFragment extends Fragment {


    public SpecialFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_special, container, false);
        initView();
        return view;
    }

    private void initView() {
        try {
            HashMap<String, String> pramrmap = new HashMap<>();

            String timestamp = String.valueOf(System.currentTimeMillis() / 1000);
            String nonce = String.valueOf((int) ((Math.random() * 9 + 1) * 100000));
            Log.i("tag", nonce);
            String key = "K;9)Bq|ScMF1h=Vp5uA-G87d(_fi[aP,.w^{vQ:W";

            String[] arrayOfstring = new String[3];
            arrayOfstring[0] = key;
            arrayOfstring[1] = timestamp;
            arrayOfstring[2] = nonce;
            Arrays.sort(arrayOfstring);
            StringBuffer sb = new StringBuffer();
            for (String s : arrayOfstring) {
                sb.append(s);
            }
            String keystr = sb.toString();

            MessageDigest digest = MessageDigest.getInstance("SHA-1");
            digest.update(keystr.getBytes());
            byte[] bytes = digest.digest();
            StringBuffer sf = new StringBuffer();
            for (int i = 0; i < bytes.length; i++) {
                String s = Integer.toHexString(bytes[i] & 0xff);
                if (s.length() < 2) {
                    sf.append(0);
                }
                sf.append(s);
            }
            String singnature = sf.toString();

            pramrmap.put("signature", singnature);
            pramrmap.put("timestamp", timestamp);
            pramrmap.put("nonce", nonce);
            pramrmap.put("from", "android");
            pramrmap.put("lang", "zh");

            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl(AppService.baseUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                    .build();
            AppService apiService = retrofit.create(AppService.class);

            /*pramrmap.put("mobile","17807193860");
            pramrmap.put("password","2013shazi");
            pramrmap.put("affirm_password","2013shazi");*/
            pramrmap.put("id", "1");
            pramrmap.put("start", "0");
            pramrmap.put("number", "0");
            pramrmap.put("point_time", "0");
            Call<ResponseBody> call = apiService.getData(pramrmap);
            call.enqueue(new Callback<ResponseBody>() {
                @Override
                public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                    try {
                        //信息
                        Log.d("tag", "请求参数：" + response.toString());
                        //请求的json串
                        String json = response.body().string();
                        Log.d("tag", "json数据：" + json);
                        //解析
//                        ChangBean changBean = new Gson().fromJson(json, ChangBean.class);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onFailure(Call<ResponseBody> call, Throwable t) {
                    Log.i("tag", t.getMessage());
                }
            });
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }

    }

}
